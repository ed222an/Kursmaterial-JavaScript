<?php 
	//sleep(2);
	
	header('Content-type: text/html; charset=utf-8'); 
?>[{"name": "Bill", "type": 2},{"name": "Sam", "type": 5},{"name": "Jason", "type": 1 }]
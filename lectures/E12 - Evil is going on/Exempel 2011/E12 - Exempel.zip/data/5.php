<?php 
	//sleep(2);
	
	header('Content-type: text/html; charset=iso-8859-1'); 
	
	
?>

<h1>Detta ritas ut om och om igen</h1>
<p>
	Siffran p� servern �r nu: <?php echo rand(0 , 1000); ?>
</p>
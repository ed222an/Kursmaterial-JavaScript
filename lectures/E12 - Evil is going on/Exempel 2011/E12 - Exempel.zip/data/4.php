<?php 
	sleep(2);
	
	header('Content-type: text/html; charset=iso-8859-1'); 
	
	
?>

<h1>H�r �r lite mer HTML kod</h1>
<p>
	Detta �r lite text.
</p>